Proyecto: Examen Parcial1 - CEL
Autor: Jorge Javier Jiménez Ruiz
Fecha: 30/09/2025

Instrucciones rápidas:
- Parte I: En la VM Ubuntu configure netplan e instale nginx.
- Parte II: Abri Cisco Packet Tracer, recree los routers/switches con el plan IP dado.
- Parte III: Cree CEL_website y comparti la carpeta con la maquina virtual.