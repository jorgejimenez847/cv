// Bloquear clic derecho y copiar
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', e => {
  if (e.ctrlKey && ['u','c','s'].includes(e.key.toLowerCase())) e.preventDefault();
  if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'i') e.preventDefault();
});
document.addEventListener('selectstart', e => e.preventDefault());
