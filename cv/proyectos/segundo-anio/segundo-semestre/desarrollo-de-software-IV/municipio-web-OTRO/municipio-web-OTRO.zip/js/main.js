// Mobile menu toggle
document.addEventListener('DOMContentLoaded', function(){
  const btn = document.getElementById('menuBtn');
  const nav = document.querySelector('nav.primary');
  btn && btn.addEventListener('click', () => {
    nav.classList.toggle('open');
  });
});