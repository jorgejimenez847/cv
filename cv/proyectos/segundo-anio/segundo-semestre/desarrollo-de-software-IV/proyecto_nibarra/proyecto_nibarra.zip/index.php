<?php
// Redirige automáticamente al login dentro de /public
header("Location: public/login.php");
exit;
