<?php
require_once __DIR__.'/../includes/config.php';
require_once __DIR__.'/../includes/auth.php';
check_auth();
include __DIR__ . '/../includes/header.php';

// Navegación de meses
$month = isset($_GET['month']) ? intval($_GET['month']) : date('n');
$year  = isset($_GET['year'])  ? intval($_GET['year'])  : date('Y');
if ($month < 1)  { $month = 12; $year--; }
if ($month > 12) { $month = 1;  $year++; }

$daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
$firstDay    = date('N', strtotime("$year-$month-01"));
$today       = date('Y-m-d');

$stmt = $pdoLocal->query("SELECT id, equipo, ingreso_fecha, salida_fecha, estado, tipo_mantenimiento, progreso FROM equipos");
$equipos = $stmt->fetchAll(PDO::FETCH_ASSOC);

$prevMonth = $month - 1; $nextMonth = $month + 1;
$prevYear = $year; $nextYear = $year;
if ($prevMonth < 1) { $prevMonth = 12; $prevYear--; }
if ($nextMonth > 12) { $nextMonth = 1; $nextYear++; }
?>

<div class="container mt-4">
  <h3>Calendario de Mantenimientos</h3>

  <div class="calendar-container" style="background:#fff;padding:20px;border-radius:12px;box-shadow:0 6px 16px rgba(0,0,0,0.06);">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <a class="btn btn-outline-primary btn-sm" href="?month=<?=$prevMonth?>&year=<?=$prevYear?>">&lt; Mes anterior</a>
      <h5 class="mb-0"><?= strftime('%B %Y', strtotime("$year-$month-01")) ?></h5>
      <a class="btn btn-outline-primary btn-sm" href="?month=<?=$nextMonth?>&year=<?=$nextYear?>">Mes siguiente &gt;</a>
    </div>

    <div class="calendar-grid text-center fw-bold text-secondary mb-2" style="display:grid;grid-template-columns:repeat(7,1fr);gap:6px;">
      <div>Lun</div><div>Mar</div><div>Mié</div><div>Jue</div><div>Vie</div><div>Sáb</div><div>Dom</div>
    </div>

    <div id="cal-grid" class="calendar-grid" style="display:grid;grid-template-columns:repeat(7,1fr);gap:6px;">
      <?php
      for ($i = 1; $i < $firstDay; $i++) {
          echo "<div></div>";
      }

      for ($d = 1; $d <= $daysInMonth; $d++) {
          $dateStr = sprintf('%04d-%02d-%02d', $year, $month, $d);
          $isToday = ($dateStr === $today) ? 'today' : '';
          echo "<div class='calendar-day day-box {$isToday}' data-date='{$dateStr}' 
                      style='position:relative;min-height:110px;border:1px solid #e0e0e0;
                             border-radius:8px;background:#fafafa;padding:6px;overflow:visible;'>";
          echo "<div class='day-num' style='font-weight:600;color:#0d6efd;margin-bottom:6px;'>$d</div>";
          echo "</div>";
      }
      ?>
    </div>
  </div>
</div>

<!-- Tooltip -->
<div id="cal-tooltip" style="
    position:absolute;
    display:none;
    z-index:99999;
    background:rgba(0,0,0,0.85);
    color:#fff;
    padding:8px 10px;
    border-radius:6px;
    font-size:13px;
    max-width:320px;">
</div>

<script>
// Equipos desde PHP
const equipos = <?= json_encode($equipos) ?>;

// Ordenar por fecha de ingreso → para priorizar líneas
equipos.sort((a, b) => {
  if (a.ingreso_fecha < b.ingreso_fecha) return -1;
  if (a.ingreso_fecha > b.ingreso_fecha) return 1;
  return 0;
});

// Formatea fecha
function dateToYMD(d) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

function applyEvents() {
  // limpiar previos
  document.querySelectorAll('.event-dot, .event-line').forEach(el => el.remove());

  // MAP: para agrupar puntos por fecha
  const puntosPorDia = {};

  equipos.forEach(eq => {
    const ingreso = eq.ingreso_fecha;
    const salida  = eq.salida_fecha;
    const terminado = String(eq.estado).toLowerCase() === "terminada";

    const info =
      `<strong>${eq.equipo}</strong> (ID ${eq.id})<br>
       Estado: ${eq.estado}<br>
       Progreso: ${eq.progreso}%<br>
       Ingreso: ${eq.ingreso_fecha}<br>
       Salida: ${eq.salida_fecha || '-'}`;

    // ----------------------------------------------------------------------
    // 1) PUNTO VERDE (TERMINADOS SIEMPRE)
    // ----------------------------------------------------------------------
    if (terminado) {
      const fecha = salida || ingreso;
      const cell = document.querySelector(`#cal-grid [data-date="${fecha}"]`);
      if (cell) {
        if (!puntosPorDia[fecha]) puntosPorDia[fecha] = [];
        puntosPorDia[fecha].push({
          eqId: eq.id,
          info: info,
          color: "#43a047"
        });
      }
      return; // no dibuja línea roja ni amarilla
    }

    // ----------------------------------------------------------------------
    // 2) EQUIPOS NO TERMINADOS
    // ----------------------------------------------------------------------

    // 2A) PUNTO AMARILLO (SIN FECHA DE SALIDA)
    if (!salida) {
      const cell = document.querySelector(`#cal-grid [data-date="${ingreso}"]`);
      if (cell) {
        if (!puntosPorDia[ingreso]) puntosPorDia[ingreso] = [];
        puntosPorDia[ingreso].push({
          eqId: eq.id,
          info: info,
          color: "#f59e0b"
        });
      }
      return; // no hay línea
    }

    // 2B) LÍNEA ROJA (NO TERMINADO + CON FECHA DE SALIDA)
    {
      const start = new Date(ingreso + "T00:00:00");
      const end   = new Date(salida + "T00:00:00");

      // offset vertical según antigüedad
      const lineIndex = equipos.findIndex(e => e.id === eq.id);
      const topOffset = 55 + (lineIndex * 8); // 8px de separación por línea

      for (let d = new Date(start); d <= end; d.setDate(d.getDate()+1)) {
        const fecha = dateToYMD(d);
        const cell = document.querySelector(`#cal-grid [data-date="${fecha}"]`);
        if (!cell) continue;

        const line = document.createElement('div');
        line.className = "event-line";
        line.dataset.info = info;
        line.dataset.eqId = eq.id;

        line.style.position = "absolute";
        line.style.left = "6px";
        line.style.right = "6px";
        line.style.top = topOffset + "px";
        line.style.height = "6px";
        line.style.background = "#e53935";
        line.style.borderRadius = "999px";
        line.style.cursor = "pointer";
        line.style.zIndex = "5";

        cell.appendChild(line);
      }

      // Punto amarillo también en ingreso
      if (!puntosPorDia[ingreso]) puntosPorDia[ingreso] = [];
      puntosPorDia[ingreso].push({
        eqId: eq.id,
        info: info,
        color: "#f59e0b"
      });
    }

  });

  // ----------------------------------------------------------------------
  // DIBUJAR PUNTOS DE TODOS LOS DÍAS
  // ----------------------------------------------------------------------
  for (const fecha in puntosPorDia) {
    const arr = puntosPorDia[fecha];
    const cell = document.querySelector(`#cal-grid [data-date="${fecha}"]`);
    if (!cell) continue;

    // Separarlos horizontalmente
    arr.forEach((p, idx) => {
      const dot = document.createElement('div');
      dot.className = "event-dot";
      dot.dataset.info = p.info;
      dot.dataset.eqId = p.eqId;

      dot.style.position = "absolute";
      dot.style.top = "6px"; // SIEMPRE ARRIBA
      dot.style.left = (10 + idx * 16) + "px"; // separación horizontal
      dot.style.width = "12px";
      dot.style.height = "12px";
      dot.style.background = p.color;
      dot.style.borderRadius = "999px";
      dot.style.cursor = "pointer";
      dot.style.zIndex = "10";

      cell.appendChild(dot);
    });
  }
}

function attachTooltips() {
  const tooltip = document.getElementById("cal-tooltip");

  document.addEventListener("mousemove", e => {
    if (tooltip.style.display !== "none") {
      tooltip.style.left = (e.pageX + 12) + "px";
      tooltip.style.top = (e.pageY + 12) + "px";
    }
  });

  document.getElementById("cal-grid").addEventListener("mouseover", e => {
    const el = e.target.closest(".event-line, .event-dot");
    if (!el) return;

    tooltip.innerHTML = el.dataset.info;
    tooltip.style.display = "block";
    tooltip.style.left = (e.pageX + 12) + "px";
    tooltip.style.top  = (e.pageY + 12) + "px";
  });

  document.getElementById("cal-grid").addEventListener("mouseleave", () => {
    tooltip.style.display = "none";
  });

  // Click a editar
  document.getElementById("cal-grid").addEventListener("click", e => {
    const el = e.target.closest(".event-line, .event-dot");
    if (!el) return;
    window.location.href = "equipos_edit.php?id=" + el.dataset.eqId;
  });
}

applyEvents();
attachTooltips();
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>