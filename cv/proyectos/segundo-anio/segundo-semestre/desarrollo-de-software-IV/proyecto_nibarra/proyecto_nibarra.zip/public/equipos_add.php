<?php
require_once __DIR__.'/../includes/config.php';
require_once __DIR__.'/../includes/replicate.php';
require_once __DIR__.'/../includes/auth.php';
check_auth();

// mismos estados que en editar
$estados = ['por hacer', 'espera material', 'en revision', 'terminada'];
$tipos   = ['preventivo','predictivo','correctivo'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ingreso_fecha      = $_POST['ingreso_fecha'] ?? date('Y-m-d');
    $salida_fecha       = $_POST['salida_fecha'] ?: null;
    $equipo             = trim($_POST['equipo'] ?? '');
    $marca              = trim($_POST['marca'] ?? '');
    $serie              = trim($_POST['serie'] ?? '');
    $tipo_servicio      = trim($_POST['tipo_servicio'] ?? '');
    $tipo_mantenimiento = $_POST['tipo_mantenimiento'] ?? 'preventivo';
    $estado             = $_POST['estado'] ?? 'por hacer';
    $costo_inicial      = $_POST['costo_inicial'] !== '' ? (float)$_POST['costo_inicial'] : 0;
    $costo_final        = $_POST['costo_final']   !== '' ? (float)$_POST['costo_final']   : 0;
    $progreso           = isset($_POST['progreso']) ? (int)$_POST['progreso'] : 0;
    $observacion        = $_POST['observacion'] ?? '';
    $material_espera    = trim($_POST['material_espera'] ?? '');

    if ($progreso < 0)   $progreso = 0;
    if ($progreso > 100) $progreso = 100;

    // Si está en "espera material", guardamos el material dentro de observación
    if (strtolower($estado) === 'espera material' && $material_espera !== '') {
        $texto = "Material en espera: " . $material_espera;
        if ($observacion !== '') {
            $observacion = $texto . " | " . $observacion;
        } else {
            $observacion = $texto;
        }
    }

    // INSERT completo según tu tabla `equipos`
    $sql = "INSERT INTO equipos (
                ingreso_fecha,
                salida_fecha,
                equipo,
                marca,
                serie,
                tipo_servicio,
                tipo_mantenimiento,
                estado,
                costo_inicial,
                costo_final,
                observacion,
                progreso
            )
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";

    $stmt = $pdoLocal->prepare($sql);
    $stmt->execute([
        $ingreso_fecha,
        $salida_fecha ?: null,
        $equipo,
        $marca,
        $serie,
        $tipo_servicio,
        $tipo_mantenimiento,
        $estado,
        $costo_inicial,
        $costo_final,
        $observacion,
        $progreso
    ]);

    $id = $pdoLocal->lastInsertId();
    replicate_row($pdoLocal, $pdoRemote, 'equipos', $id);

    header('Location: equipos_list.php');
    exit;
}
?>

<?php include __DIR__ . '/../includes/header.php'; ?>

<div class="container mt-4">
  <h3>Nuevo ingreso de equipo</h3>

  <form method="post" class="mb-4">
    <div class="row">
      <div class="col-md-3 mb-2">
        <label>Ingreso</label>
        <input type="date" name="ingreso_fecha"
               class="form-control"
               value="<?= date('Y-m-d') ?>" required>
      </div>
      <div class="col-md-3 mb-2">
        <label>Salida</label>
        <input type="date" name="salida_fecha" class="form-control">
      </div>
      <div class="col-md-6 mb-2">
        <label>Equipo</label>
        <input type="text" name="equipo" class="form-control" required>
      </div>
    </div>

    <div class="row">
      <div class="col-md-3 mb-2">
        <label>Marca</label>
        <input type="text" name="marca" class="form-control">
      </div>
      <div class="col-md-3 mb-2">
        <label>Serie</label>
        <input type="text" name="serie" class="form-control">
      </div>
      <div class="col-md-6 mb-2">
        <label>Tipo de servicio</label>
        <input type="text" name="tipo_servicio" class="form-control">
      </div>
    </div>

    <div class="row">
      <div class="col-md-4 mb-2">
        <label>Tipo de mantenimiento</label>
        <select name="tipo_mantenimiento" class="form-control">
          <?php foreach ($tipos as $t): ?>
            <option value="<?= $t ?>"><?= ucfirst($t) ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-4 mb-2">
        <label>Estado</label>
        <select id="estadoSelect" name="estado" class="form-control">
          <?php foreach ($estados as $e): ?>
            <option value="<?= $e ?>"><?= ucfirst($e) ?></option>
          <?php endforeach; ?>
        </select>

        <!-- Solo visible cuando el estado sea "espera material" -->
        <input type="text"
               name="material_espera"
               id="materialEspera"
               class="form-control mt-2 d-none"
               placeholder="Material que se está esperando">
      </div>

      <div class="col-md-4 mb-2">
        <label>Progreso (%)</label>
        <input type="number" name="progreso" class="form-control"
               min="0" max="100" value="0">
      </div>
    </div>

    <div class="row">
      <div class="col-md-6 mb-2">
        <label>Costo inicial</label>
        <input type="number" step="0.01" name="costo_inicial"
               class="form-control" value="0">
      </div>
      <div class="col-md-6 mb-2">
        <label>Costo final</label>
        <input type="number" step="0.01" name="costo_final"
               class="form-control" value="0">
      </div>
    </div>

    <div class="mb-3">
      <label>Observación</label>
      <textarea name="observacion" class="form-control" rows="3"></textarea>
    </div>

    <button class="btn btn-success">Guardar</button>
    <a href="equipos_list.php" class="btn btn-secondary">Volver</a>
  </form>
</div>

<script>
// Mostrar/ocultar el campo "material en espera" según el estado
document.addEventListener('DOMContentLoaded', () => {
  const estado  = document.getElementById('estadoSelect');
  const matWrap = document.getElementById('materialEspera');

  function toggleMaterial() {
    if (!estado) return;
    if (estado.value.toLowerCase() === 'espera material') {
      matWrap.classList.remove('d-none');
    } else {
      matWrap.classList.add('d-none');
      matWrap.value = '';
    }
  }

  estado.addEventListener('change', toggleMaterial);
  toggleMaterial();
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>