<?php
// actions.php
require_once 'db_config.php';
require_once 'db_functions.php';

$action = $_POST['action'] ?? null;
$db = $_POST['db'] ?? null;
$table = $_POST['table'] ?? null;
$message = '';

if (!$action || !$db || !$table) {
    die(json_encode(['error' => 'Datos incompletos']));
}

useDatabases($pdoLocal, $pdoRemote, $db);

if ($action === 'insert') {
    $fields = $_POST['fields'] ?? [];
    $cols = array_keys($fields);
    $place = implode(',', array_map(fn($c) => "`$c`", $cols));
    $holders = implode(',', array_map(fn($c) => ":$c", $cols));
    $sql = "INSERT INTO `$table` ($place) VALUES ($holders)";
    $res = execOnBoth($pdoLocal, $pdoRemote, $sql, $fields);
} elseif ($action === 'delete') {
    $id = $_POST['id'] ?? null;
    $sql = "DELETE FROM `$table` WHERE id = :id";
    $res = execOnBoth($pdoLocal, $pdoRemote, $sql, ['id' => $id]);
} elseif ($action === 'update') {
    $id = $_POST['id'] ?? null;
    $fields = $_POST['fields'] ?? [];
    $sets = implode(',', array_map(fn($c) => "`$c` = :$c", array_keys($fields)));
    $sql = "UPDATE `$table` SET $sets WHERE id = :id";
    $params = $fields;
    $params['id'] = $id;
    $res = execOnBoth($pdoLocal, $pdoRemote, $sql, $params);
}

if ($res['ok']) {
    echo json_encode(['ok' => true]);
} else {
    echo json_encode(['ok' => false, 'error' => $res['error']]);
}
?>
