<?php
// db_config.php
// Configuración de conexiones a las dos bases de datos

$configLocal = [
    'host' => '127.0.0.1',
    'port' => 3306,
    'user' => 'root',
    'pass' => '', // contraseña local
];

$configRemote = [
    'host' => '192.168.56.101', // IP de tu máquina virtual
    'port' => 3306,
    'user' => 'syncuser',
    'pass' => 'SyncPass123!', // contraseña creada en la VM
];

// Función para conectar vía PDO
function connectPDO($c)
{
    $dsn = "mysql:host={$c['host']};port={$c['port']};charset=utf8mb4";
    try {
        $pdo = new PDO($dsn, $c['user'], $c['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        return $pdo;
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}

$pdoLocal = connectPDO($configLocal);
$pdoRemote = connectPDO($configRemote);
?>
