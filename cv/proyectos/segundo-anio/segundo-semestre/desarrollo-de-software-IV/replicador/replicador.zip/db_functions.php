<?php
// db_functions.php

function connStatus($pdo)
{
    if (is_array($pdo) && isset($pdo['error'])) return $pdo['error'];
    return true;
}

function listDatabases($pdo)
{
    $stmt = $pdo->query("SHOW DATABASES");
    $dbs = [];
    while ($r = $stmt->fetch(PDO::FETCH_NUM)) {
        $name = $r[0];
        if (!in_array($name, ['information_schema', 'mysql', 'performance_schema', 'sys'])) {
            $dbs[] = $name;
        }
    }
    return $dbs;
}

function useDatabases(&$pdoL, &$pdoR, $db)
{
    $pdoL->exec("USE `{$db}`");
    $pdoR->exec("USE `{$db}`");
}

function listCommonTables(PDO $p1, PDO $p2, $db)
{
    $p1->exec("USE `{$db}`");
    $p2->exec("USE `{$db}`");

    $t1 = $p1->query("SHOW TABLES")->fetchAll(PDO::FETCH_NUM);
    $t2 = $p2->query("SHOW TABLES")->fetchAll(PDO::FETCH_NUM);

    $t1 = array_map(fn($r) => $r[0], $t1);
    $t2 = array_map(fn($r) => $r[0], $t2);
    return array_values(array_intersect($t1, $t2));
}

function getColumns(PDO $p, $table)
{
    $stmt = $p->query("DESCRIBE `{$table}`");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getRows(PDO $p, $table)
{
    $stmt = $p->query("SELECT * FROM `{$table}` LIMIT 200");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function execOnBoth(PDO $p1, PDO $p2, $sql, $params = [])
{
    try {
        $p1->beginTransaction();
        $p2->beginTransaction();

        $st1 = $p1->prepare($sql);
        $st2 = $p2->prepare($sql);

        $st1->execute($params);
        $st2->execute($params);

        $p1->commit();
        $p2->commit();
        return ['ok' => true];
    } catch (Exception $e) {
        try {
            if ($p1->inTransaction()) $p1->rollBack();
        } catch (Exception $ee) {
        }
        try {
            if ($p2->inTransaction()) $p2->rollBack();
        } catch (Exception $ee) {
        }
        return ['ok' => false, 'error' => $e->getMessage()];
    }
}
?>
