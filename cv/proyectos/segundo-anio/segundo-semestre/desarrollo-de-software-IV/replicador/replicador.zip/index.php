<?php
require_once 'db_config.php';
require_once 'db_functions.php';

$commonDBs = [];
if (connStatus($pdoLocal) === true && connStatus($pdoRemote) === true) {
    $dbL = listDatabases($pdoLocal);
    $dbR = listDatabases($pdoRemote);
    $commonDBs = array_values(array_intersect($dbL, $dbR));
}

$selectedDB = $_GET['db'] ?? null;
$selectedTable = $_GET['table'] ?? null;
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Replicador Local ⇄ Virtual</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h1>Replicador Local ⇄ Virtual</h1>

<?php if (connStatus($pdoLocal) !== true || connStatus($pdoRemote) !== true): ?>
<div class="error">
  <p><strong>Error de conexión:</strong></p>
  <p>Local: <?= is_array($pdoLocal) ? htmlspecialchars($pdoLocal['error']) : 'OK' ?></p>
  <p>Remoto: <?= is_array($pdoRemote) ? htmlspecialchars($pdoRemote['error']) : 'OK' ?></p>
</div>
<?php else: ?>
<form method="get" class="selector">
  <label>Base de datos:</label>
  <select name="db" onchange="this.form.submit()">
    <option value="">-- Selecciona --</option>
    <?php foreach ($commonDBs as $db): ?>
      <option value="<?= htmlspecialchars($db) ?>" <?= $db == $selectedDB ? 'selected' : '' ?>><?= htmlspecialchars($db) ?></option>
    <?php endforeach; ?>
  </select>
</form>

<?php if ($selectedDB): ?>
  <?php $tables = listCommonTables($pdoLocal, $pdoRemote, $selectedDB); ?>
  <form method="get" class="selector">
    <input type="hidden" name="db" value="<?= htmlspecialchars($selectedDB) ?>">
    <label>Tabla:</label>
    <select name="table" onchange="this.form.submit()">
      <option value="">-- Selecciona --</option>
      <?php foreach ($tables as $t): ?>
        <option value="<?= htmlspecialchars($t) ?>" <?= $t == $selectedTable ? 'selected' : '' ?>><?= htmlspecialchars($t) ?></option>
      <?php endforeach; ?>
    </select>
  </form>
<?php endif; ?>

<?php if ($selectedTable): ?>
  <?php
  useDatabases($pdoLocal, $pdoRemote, $selectedDB);
  $cols = getColumns($pdoLocal, $selectedTable);
  $rows = getRows($pdoLocal, $selectedTable);
  $colNames = array_map(fn($c) => $c['Field'], $cols);
  ?>
  <h2>Tabla: <?= htmlspecialchars($selectedTable) ?></h2>
  <table>
    <thead>
      <tr>
        <?php foreach ($colNames as $c): ?><th><?= htmlspecialchars($c) ?></th><?php endforeach; ?>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <?php foreach ($colNames as $c): ?>
            <td><?= htmlspecialchars($r[$c] ?? '') ?></td>
          <?php endforeach; ?>
          <td>
            <button onclick='editRow(<?= json_encode($r) ?>)'>Editar</button>
            <button onclick='deleteRow(<?= $r["id"] ?? 0 ?>)'>Borrar</button>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <button onclick="showInsert()">Nuevo registro</button>

  <div id="formBox" class="modal"></div>
<?php endif; ?>

<?php endif; ?>
</div>
<script>
const db = "<?= $selectedDB ?>";
const table = "<?= $selectedTable ?>";

function ajax(action, data, cb){
  data.append("action", action);
  data.append("db", db);
  data.append("table", table);
  fetch("actions.php", {method:"POST", body:data})
    .then(r=>r.json())
    .then(res=>{alert(res.ok?"Operación realizada":"Error: "+res.error); location.reload();});
}

function deleteRow(id){
  if(!confirm("¿Eliminar registro?")) return;
  let d = new FormData();
  d.append("id", id);
  ajax("delete", d);
}

function editRow(row){
  const modal = document.getElementById("formBox");
  modal.innerHTML = "";
  const form = document.createElement("form");
  form.innerHTML = `<h3>Editar registro</h3>`;
  form.appendChild(newInput("hidden","id", row.id));
  for(let k in row){
    if(k=="id") continue;
    form.appendChild(newInput("text", "fields["+k+"]", row[k]));
  }
  form.appendChild(btn("Guardar", ()=>submitForm(form,"update")));
  modal.appendChild(form);
}

function showInsert(){
  const modal = document.getElementById("formBox");
  modal.innerHTML = "";
  const form = document.createElement("form");
  form.innerHTML = `<h3>Insertar nuevo</h3>`;
  <?php foreach($colNames as $c): if($c=="id") continue; ?>
  form.appendChild(newInput("text","fields[<?= $c ?>]",""));
  <?php endforeach; ?>
  form.appendChild(btn("Insertar", ()=>submitForm(form,"insert")));
  modal.appendChild(form);
}

function newInput(type,name,value){
  const div=document.createElement("div");
  div.className="input";
  div.innerHTML=`<label>${name}</label><input type="${type}" name="${name}" value="${value??''}">`;
  return div;
}

function btn(label, fn){
  const b=document.createElement("button");
  b.textContent=label;
  b.type="button";
  b.onclick=fn;
  return b;
}

function submitForm(form,action){
  const data=new FormData(form);
  ajax(action,data);
}
</script>
</body>
</html>
