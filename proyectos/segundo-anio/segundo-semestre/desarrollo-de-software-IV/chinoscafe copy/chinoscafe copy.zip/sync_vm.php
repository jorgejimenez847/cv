<?php
// sync_vm.php — Ejecuta la sincronización VM → Local y muestra resultado
require_once 'replicate_pull.php';
?>