<?php
require_once 'db.php';
require_once 'auth.php';
require_auth();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['action']) && $_POST['action'] === 'delete' && !empty($_POST['id'])) {
        $id = intval($_POST['id']);
        // Eliminar primero los sale_items relacionados
        $delItems = $mysqli->prepare("DELETE FROM sale_items WHERE product_id = ?");
        $delItems->bind_param('i', $id);
        $delItems->execute();
        // Luego eliminar el producto
        $stmt = $mysqli->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();

        flash_set('success','Producto eliminado.');
        header('Location: products.php');
        exit;
    }
}

$qsearch = trim($_GET['q'] ?? '');
$where = '';
if ($qsearch !== '') {
    $esc = $mysqli->real_escape_string($qsearch);
    $where = "WHERE p.name LIKE '%{$esc}%' OR p.code LIKE '%{$esc}%'";
}

$products = $mysqli->query("SELECT p.*, s.name as supplier_name FROM products p LEFT JOIN suppliers s ON p.supplier_id = s.id $where ORDER BY p.name LIMIT 100");

include 'header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h3>Productos</h3>
  <div>
    <a class="btn btn-sm btn-primary" href="add_product.php">Nuevo producto</a>
  </div>
</div>

<form class="row g-2 mb-3" method="get">
  <div class="col-auto"><input name="q" value="<?php echo htmlspecialchars($qsearch); ?>" class="form-control" placeholder="Buscar por nombre o código"></div>
  <div class="col-auto"><button class="btn btn-outline-primary">Buscar</button></div>
</form>

<table class="table table-striped">
  <thead><tr><th>Código</th><th>Nombre</th><th>Proveedor</th><th>Precio</th><th>Stock</th><th></th></tr></thead>
  <tbody>
    <?php while($p = $products->fetch_assoc()): ?>
      <tr>
        <td><?php echo htmlspecialchars($p['code']); ?></td>
        <td><?php echo htmlspecialchars($p['name']); ?></td>
        <td><?php echo htmlspecialchars($p['supplier_name']); ?></td>
        <td><?php echo number_format($p['price'],2); ?></td>
        <td><?php echo intval($p['stock']); ?></td>
        <td>
          <a class="btn btn-sm btn-outline-secondary" href="edit_product.php?id=<?php echo $p['id']; ?>">Editar</a>
          <form method="post" style="display:inline" onsubmit="return confirm('Eliminar producto?');">
            <input type="hidden" name="id" value="<?php echo $p['id']; ?>">
            <input type="hidden" name="action" value="delete">
            <button class="btn btn-sm btn-danger">Eliminar</button>
          </form>
        </td>
      </tr>
    <?php endwhile; ?>
  </tbody>
</table>

<?php include 'footer.php'; ?>
