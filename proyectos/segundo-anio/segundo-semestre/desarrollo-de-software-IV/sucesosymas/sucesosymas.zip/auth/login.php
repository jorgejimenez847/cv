<?php
require_once __DIR__ . '/../includes/db.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $correo = trim($_POST['correo']);
    $pass   = $_POST['password'];
    
    $stmt = $mysqli->prepare("SELECT id_clientes, nombre, contraseña, rol FROM clientes WHERE correo_electronico = ? LIMIT 1");
    $stmt->bind_param('s', $correo);
    $stmt->execute();
    $res = $stmt->get_result();

    if($res && $res->num_rows === 1){
        $u = $res->fetch_assoc();
        $hash = $u['contraseña'];

        // Si la contraseña está encriptada, la verifica. Si no, compara directa (por compatibilidad)
        if (password_verify($pass, $hash) || $pass === $hash) {
            $_SESSION['cliente'] = [
                'id'=>$u['id_clientes'],
                'nombre'=>$u['nombre'],
                'correo'=>$correo,
                'rol'=>$u['rol']
            ];
            header('Location: ../index.php');
            exit;
        }
    }
    $error = "Credenciales inválidas";
}
?>

<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Login - Sucesos y Más</title>
<link rel="stylesheet" href="../css/estilos.css">
<style>
body{display:flex;align-items:center;justify-content:center;height:100vh;background:#f5f6fa;}
.login-box{background:white;padding:30px 40px;border-radius:12px;box-shadow:0 0 12px rgba(0,0,0,.2);width:360px;}
.login-box h2{text-align:center;margin-bottom:20px;color:#2c3e50;}
.login-box input{width:100%;padding:10px;margin:8px 0;border:1px solid #ccc;border-radius:6px;}
.login-box button{width:100%;padding:10px;background:#2c3e50;color:white;border:none;border-radius:6px;cursor:pointer;}
.login-box button:hover{background:#1a252f;}
.msg-error{color:#c0392b;text-align:center;margin-top:8px;}
</style>
</head>
<body>
<div class="login-box">
<h2>Iniciar sesión</h2>
<form method="post">
  <input type="email" name="correo" placeholder="Correo electrónico" required>
  <input type="password" name="password" placeholder="Contraseña" required>
  <button>Entrar</button>
</form>
<?php if(!empty($error)) echo "<div class='msg-error'>$error</div>"; ?>
<p style='text-align:center;margin-top:10px;'>¿No tienes cuenta? <a href='register.php'>Regístrate</a></p>
</div>
</body>
</html>