<?php
session_start();
if (!isset($_SESSION['cliente'])) {
    header("Location: ../index.php");
    exit;
}
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Confirmar salida</title>
<link rel="stylesheet" href="../css/estilos.css">
<style>
body{display:flex;align-items:center;justify-content:center;height:100vh;background:#f5f6fa;}
.box{background:white;padding:30px;border-radius:12px;box-shadow:0 0 12px rgba(0,0,0,.2);text-align:center;}
button{margin:8px 12px;padding:10px 20px;border:none;border-radius:6px;cursor:pointer;font-size:15px;}
.ok{background:#27ae60;color:white;}
.cancel{background:#e74c3c;color:white;}
button:hover{opacity:.85;}
</style>
</head>
<body>
<div class="box">
  <h3>¿Deseas cerrar la sesión de <b><?= htmlspecialchars($_SESSION['cliente']['nombre']) ?></b>?</h3>
  <form method="post" action="logout.php">
    <button type="submit" name="confirmar" value="1" class="ok">Sí, salir</button>
    <button type="button" class="cancel" onclick="window.location.href='../index.php'">Cancelar</button>
  </form>
</div>
</body>
</html>
