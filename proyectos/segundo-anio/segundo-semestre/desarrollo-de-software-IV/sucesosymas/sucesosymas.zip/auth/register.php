<?php
require_once __DIR__ . '/../includes/db.php';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $nombre = trim($_POST['nombre']);
    $correo = trim($_POST['correo']);
    $pass   = $_POST['password'];

    if(empty($nombre) || empty($correo) || empty($pass)){
        $error = "Complete todos los campos";
    } else {
        // Detectar rol por el dominio del correo
        $rol = (str_ends_with($correo, '@admin')) ? 'admin' : 'cliente';

        // Verificar si ya existe ese correo
        $check = $mysqli->prepare("SELECT id_clientes FROM clientes WHERE correo_electronico = ?");
        $check->bind_param('s', $correo);
        $check->execute();
        $res = $check->get_result();

        if($res && $res->num_rows > 0){
            $error = "Ese correo ya está registrado.";
        } else {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $mysqli->prepare("INSERT INTO clientes (nombre, correo_electronico, contraseña, rol) VALUES (?,?,?,?)");
            $stmt->bind_param('ssss', $nombre, $correo, $hash, $rol);
            if($stmt->execute()){
                header('Location: login.php?msg=registered');
                exit;
            } else {
                $error = "Error al registrar: " . $stmt->error;
            }
        }
    }
}
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Registro - Sucesos y Más</title>
<link rel="stylesheet" href="../css/estilos.css">
<style>
body{display:flex;align-items:center;justify-content:center;height:100vh;background:#f5f6fa;}
.register-box{background:white;padding:30px 40px;border-radius:12px;box-shadow:0 0 12px rgba(0,0,0,.2);width:380px;}
.register-box h2{text-align:center;margin-bottom:20px;color:#2c3e50;}
.register-box input{width:100%;padding:10px;margin:8px 0;border:1px solid #ccc;border-radius:6px;}
.register-box button{width:100%;padding:10px;background:#2c3e50;color:white;border:none;border-radius:6px;cursor:pointer;}
.register-box button:hover{background:#1a252f;}
.msg-error{color:#c0392b;text-align:center;margin-top:8px;}
.msg-ok{color:#27ae60;text-align:center;margin-top:8px;}
</style>
</head>
<body>
<div class="register-box">
<h2>Registro de usuario</h2>
<form method="post">
    <input name="nombre" placeholder="Nombre completo" required>
    <input name="correo" type="email" placeholder="Correo electrónico" required>
    <input name="password" type="password" placeholder="Contraseña" required>
    <button>Registrar</button>
</form>
<?php
if(!empty($error)) echo "<div class='msg-error'>$error</div>";
if(!empty($_GET['msg']) && $_GET['msg']=='registered')
    echo "<div class='msg-ok'>Registro exitoso. Puedes iniciar sesión.</div>";
?>
<p style='text-align:center;margin-top:10px;'>¿Ya tienes cuenta? <a href='login.php'>Inicia sesión</a></p>
</div>
</body>
</html>