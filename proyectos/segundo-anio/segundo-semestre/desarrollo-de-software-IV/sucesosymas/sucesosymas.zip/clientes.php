<?php

if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'])) {
    header('Location: index.php?p=clientes');
    exit;
}

if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['cliente']) || $_SESSION['cliente']['rol'] !== 'admin') {
    echo "<p style='color:red;'>Acceso restringido a administradores.</p>";
    exit;
}

// Guardar nuevo cliente
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $correo = trim($_POST['correo']);
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $rol = (strpos($correo, '@admin') !== false) ? 'admin' : 'cliente';

    $existe = $mysqli->prepare("SELECT id_clientes FROM clientes WHERE correo_electronico=?");
    $existe->bind_param('s', $correo);
    $existe->execute();
    if ($existe->get_result()->num_rows > 0) {
        $msg = "<div class='msg error'>❌ El correo ya está registrado.</div>";
    } else {
        $stmt = $mysqli->prepare("INSERT INTO clientes (nombre, correo_electronico, contraseña, rol) VALUES (?,?,?,?)");
        $stmt->bind_param('ssss', $nombre, $correo, $pass, $rol);
        $stmt->execute();
        $msg = "<div class='msg ok'>✅ Cliente agregado correctamente.</div>";
    }
}

$res = $mysqli->query("SELECT * FROM clientes WHERE rol='cliente' ORDER BY id_clientes DESC");

?>
        <h2>Clientes</h2>
        <?= $msg ?? '' ?>
        <form method="post">
            <label>Nombre:<input name="nombre" required></label><br>
            <label>Correo:<input name="correo" type="email" required></label><br>
            <label>Contraseña:<input name="password" type="password" required></label><br>
            <button>Guardar</button>
        </form>

        <table class="tabla">
            <thead><tr><th>ID</th><th>Nombre</th><th>Correo</th><th>Rol</th></tr></thead>
            <tbody>
                <?php while($r = $res->fetch_assoc()): ?>
                <tr>
                    <td><?= $r['id_clientes'] ?></td>
                    <td><?= htmlspecialchars($r['nombre']) ?></td>
                    <td><?= htmlspecialchars($r['correo_electronico']) ?></td>
                    <td><?= $r['rol'] ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>