<?php

// Evitar acceso directo
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'])) {
    header('Location: index.php?p=contactos');
    exit;
}

if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'includes/db.php';

$rol = $_SESSION['cliente']['rol'] ?? 'invitado';
$idCliente = $_SESSION['cliente']['id'] ?? null;
$nombre = $_SESSION['cliente']['nombre'] ?? null;
if ($rol === 'cliente' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $mensaje = trim($_POST['mensaje']);
    if ($mensaje !== '') {
        $stmt = $mysqli->prepare("INSERT INTO mensajes (id_cliente, remitente, contenido) VALUES (?, ?, ?)");
        $stmt->bind_param('iss', $idCliente, $nombre, $mensaje);
        $stmt->execute();
        $msg = "<div class='msg ok'>✅ Mensaje enviado correctamente.</div>";
    }
}

if ($rol === 'admin' && isset($_GET['atender'])) {
    $id = intval($_GET['atender']);
    $mysqli->query("DELETE FROM mensajes WHERE id_mensajes=$id");
    echo "<script>alert('Cliente atendido!'); window.location='contactos.php';</script>";
    exit;
}
?>

<h2>Contactos</h2>
<?= $msg ?? '' ?>

<?php if ($rol === 'admin'): ?>
    <h3>Mensajes de Clientes</h3>
    <table class="tabla">
        <thead>
            <tr>
                <th>ID</th>
                <th>Remitente</th>
                <th>Mensaje</th>
                <th>Fecha</th>
                <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $res = $mysqli->query("SELECT * FROM mensajes ORDER BY fecha DESC");
            while($m=$res->fetch_assoc()): ?>
            <tr>
                <td><?= $m['id_mensajes'] ?></td>
                <td><?= htmlspecialchars($m['remitente']) ?></td>
                <td><?= htmlspecialchars($m['contenido']) ?></td>
                <td><?= $m['fecha'] ?></td>
                <td>
                    <a href="?atender=<?= $m['id_mensajes'] ?>" class="btn btn-success btn-sm">Atender cliente</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

<?php elseif ($rol === 'cliente'): ?>
    <form method="post">
        <p>Enviando como <strong><?= htmlspecialchars($nombre) ?></strong></p>
        <textarea name="mensaje" required></textarea><br>
        <button>Enviar</button>
    </form>

<?php else: ?>
    <p>Debes iniciar sesión para usar el formulario de contacto.</p>
<?php endif; ?>

</div>
</div>