<?php

// Evitar acceso directo directo
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'])) {
    header('Location: index.php?p=cotizaciones');
    exit;
}

if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['cliente'])) {
    header('Location: auth/login.php');
    exit;
}

$rol = $_SESSION['cliente']['rol'];
$cliente_id = $_SESSION['cliente']['id'] ?? null;
if ($rol === 'admin') {

    // Aceptar
    if (isset($_GET['aceptar'])) {
        $id = intval($_GET['aceptar']);

        // Cambiar estado
        $mysqli->query("UPDATE cotizaciones SET estado='aceptada' WHERE id_cotizaciones=$id");

        // Copiar a solicitudes
        $sql = "INSERT INTO solicitudes (id_cliente, nombre, cantidad, costo, unidad, creado)
                SELECT c.id_cliente, m.nombre, c.cantidad, m.costo, m.unidad, NOW()
                FROM cotizaciones c
                JOIN materiales m ON c.id_material = m.id_materiales
                WHERE c.id_cotizaciones = $id";
        $mysqli->query($sql);

        header("Location: cotizaciones.php");
        exit;
    }

    // Denegar
    if (isset($_GET['denegar'])) {
        $id = intval($_GET['denegar']);
        $mysqli->query("UPDATE cotizaciones SET estado='denegada' WHERE id_cotizaciones=$id");
        header("Location: cotizaciones.php");
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $rol === 'cliente') {
    $material = intval($_POST['material']);
    $cantidad = intval($_POST['cantidad']);
    $res = $mysqli->query("SELECT cantidad, costo FROM materiales WHERE id_materiales=$material LIMIT 1");
    $row = $res->fetch_assoc();

    if ($row && $cantidad <= $row['cantidad'] && $cantidad > 0) {
        $total = $cantidad * $row['costo'];
        $stmt = $mysqli->prepare("INSERT INTO cotizaciones (id_cliente, id_material, cantidad, costo_total, estado)
                                  VALUES (?,?,?,?, 'pendiente')");
        $stmt->bind_param('iiid', $cliente_id, $material, $cantidad, $total);
        $stmt->execute();

        // Reducir stock
        if ($stmt->affected_rows > 0) {
            $upd = $mysqli->prepare("UPDATE materiales SET cantidad = GREATEST(cantidad - ?, 0) WHERE id_materiales = ?");
            $upd->bind_param('ii', $cantidad, $material);
            $upd->execute();
            $upd->close();
        }
        $stmt->close();
    }
}

if ($rol === 'admin') {
    // Solo pendientes para admin
    $res = $mysqli->query("SELECT c.*, cli.nombre AS cliente, m.nombre AS material 
                           FROM cotizaciones c
                           LEFT JOIN clientes cli ON cli.id_clientes=c.id_cliente
                           LEFT JOIN materiales m ON m.id_materiales=c.id_material
                           WHERE c.estado='pendiente'
                           ORDER BY c.id_cotizaciones DESC");
} else {
    // Cliente ve todas
    $res = $mysqli->query("SELECT c.*, m.nombre AS material 
                           FROM cotizaciones c
                           LEFT JOIN materiales m ON m.id_materiales=c.id_material
                           WHERE c.id_cliente=$cliente_id
                           ORDER BY c.id_cotizaciones DESC");
}
?>

<h2>Cotizaciones</h2>

<?php if ($rol === 'cliente'): ?>
<form method="post">
    <label>Material:
        <select name="material">
            <?php
            $mat = $mysqli->query("SELECT * FROM materiales WHERE cantidad>0");
            while($m=$mat->fetch_assoc()): ?>
                <option value="<?= $m['id_materiales'] ?>"><?= htmlspecialchars($m['nombre']) ?></option>
            <?php endwhile; ?>
        </select>
    </label>
    <label>Cantidad:
        <input name="cantidad" type="number" min="1" required>
    </label>
    <button>Generar Cotización</button>
</form>
<?php endif; ?>

<table class="tabla">
    <thead>
        <tr>
            <th>ID</th>
            <?php if($rol==='admin') echo '<th>Cliente</th>'; ?>
            <th>Material</th>
            <th>Cantidad</th>
            <th>Total</th>
            <th>Estado</th>
            <?php if($rol==='admin') echo '<th>Acción</th>'; else echo '<th>Factura</th>'; ?>
        </tr>
    </thead>
    <tbody>
        <?php while($r=$res->fetch_assoc()): 
            $estado = isset($r['estado']) && $r['estado'] !== null ? $r['estado'] : 'pendiente';
            $color = ($estado === 'aceptada') ? 'style="background:#d4edda;"' : ''; ?>
        <tr <?= $color ?>>
            <td><?= $r['id_cotizaciones'] ?></td>
            <?php if($rol==='admin'): ?><td><?= htmlspecialchars($r['cliente']) ?></td><?php endif; ?>
            <td><?= htmlspecialchars($r['material']) ?></td>
            <td><?= $r['cantidad'] ?></td>
            <td><?= number_format($r['costo_total'],2) ?></td>
            <td><?= htmlspecialchars(ucfirst($estado)) ?></td>
            <?php if($rol==='admin'): ?>
                <td>
                    <a href="?aceptar=<?= $r['id_cotizaciones'] ?>" class="btn btn-success btn-sm">Aceptar ✅</a>
                    <a href="?denegar=<?= $r['id_cotizaciones'] ?>" class="btn btn-danger btn-sm">Denegar ❌</a>
                </td>
            <?php else: ?>
                <td>
                    <form action="factura/generar.php" method="get" style="display:inline;">
                        <input type="hidden" name="cot" value="<?= $r['id_cotizaciones'] ?>">
                        <input type="hidden" name="download" value="1">
                        <button type="submit" class="btn btn-primary">Descargar PDF</button>
                    </form>
                </td>
            <?php endif; ?>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>
</div>
</div>