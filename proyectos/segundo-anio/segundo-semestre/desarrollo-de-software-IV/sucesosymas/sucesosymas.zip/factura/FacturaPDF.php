<?php
require_once __DIR__ . '/../lib/fpdf.php';

class FacturaPDF {
    public static function generar($factura, $material, $nombreCliente, $cantidad, $idFactura) {
        $pdf = new FPDF('P', 'mm', 'A4');
        $pdf->AddPage();
        $pdf->SetFont('Arial','B',18);
        $pdf->Cell(190,10,'FERRETERIA SUCESOS Y MAS',0,1,'C');
        $pdf->SetFont('Arial','',12);
        $pdf->Cell(190,8,'Factura N° '.$idFactura,0,1,'C');
        $pdf->Ln(10);
        $pdf->Cell(190,8,'Cliente: '.$nombreCliente,0,1);
        $pdf->Cell(190,8,'Fecha: '.$factura['fecha'],0,1);
        $pdf->Ln(5);

        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(80,8,'Material',1,0,'C');
        $pdf->Cell(30,8,'Cantidad',1,0,'C');
        $pdf->Cell(40,8,'Costo Unit.',1,0,'C');
        $pdf->Cell(40,8,'Subtotal',1,1,'C');

        $pdf->SetFont('Arial','',12);
        $subtotal = $material['costo'] * $cantidad;
        $itbm = $subtotal * ($factura['itbm'] / 100);
        $total = $subtotal + $itbm;

        $pdf->Cell(80,8,$material['nombre'],1,0);
        $pdf->Cell(30,8,$cantidad,1,0,'C');
        $pdf->Cell(40,8,'$'.number_format($material['costo'],2),1,0,'R');
        $pdf->Cell(40,8,'$'.number_format($subtotal,2),1,1,'R');

        $pdf->Ln(5);
        $pdf->Cell(150,8,'Subtotal:',0,0,'R');
        $pdf->Cell(40,8,'$'.number_format($subtotal,2),0,1,'R');
        $pdf->Cell(150,8,'ITBM ('.$factura['itbm'].'%):',0,0,'R');
        $pdf->Cell(40,8,'$'.number_format($itbm,2),0,1,'R');
        $pdf->Cell(150,8,'Total a pagar:',0,0,'R');
        $pdf->Cell(40,8,'$'.number_format($total,2),0,1,'R');

        $pdf->Ln(15);
        $pdf->SetFont('Arial','I',10);
        $pdf->Cell(190,8,'Gracias por su compra en Ferretería Sucesos y Más.',0,1,'C');

        $path = __DIR__."/../facturas/factura_$idFactura.pdf";
        $pdf->Output('F', $path);
        return $path;
    }
}
