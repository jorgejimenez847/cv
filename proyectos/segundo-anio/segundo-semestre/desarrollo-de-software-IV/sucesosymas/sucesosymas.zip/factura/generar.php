<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/FacturaPDF.php';
session_start();

$isDownload = isset($_GET['download']) && $_GET['download'] == 1;

if (!$isDownload) {
    include '../header.php';
    echo '<div id="contenedor">';
    include '../menu.php';
    echo '<div id="contenido">';
}

if (!isset($_GET['cot'])) {
    echo "<p>No se especificó una cotización.</p>";
} else {
    $idCot = intval($_GET['cot']);
    $q = $mysqli->query("SELECT * FROM cotizaciones WHERE id_cotizaciones = $idCot LIMIT 1");
    if (!$q || $q->num_rows === 0) {
        echo "<p>Cotización no encontrada.</p>";
    } else {
        $cot = $q->fetch_assoc();

        $clienteRes = $mysqli->query("SELECT nombre FROM clientes WHERE id_clientes = " . intval($cot['id_cliente']));
        $cliente = $clienteRes->fetch_assoc() ?: ['nombre' => 'Cliente N/A'];

        $matRes = $mysqli->query("SELECT * FROM materiales WHERE id_materiales = " . intval($cot['id_material']));
        $mat = $matRes->fetch_assoc() ?: ['nombre' => 'Material N/A', 'costo' => 0, 'unidad' => 'unidad'];

        $cantidad = intval($cot['cantidad']);
        $precioUnit = floatval($mat['costo']);
        $subtotal = $precioUnit * $cantidad;
        $itbm_porcentaje = 7.00;
        $itbm_val = $subtotal * ($itbm_porcentaje / 100);
        $total = $subtotal + $itbm_val;

        $stmt = $mysqli->prepare("INSERT INTO facturas (id_cliente, id_material, itbm, total, cantidad) VALUES (?,?,?,?,?)");
        $stmt->bind_param('iiidi', $cot['id_cliente'], $cot['id_material'], $itbm_porcentaje, $total, $cantidad);
        $stmt->execute();
        $idFactura = $mysqli->insert_id;
        $stmt->close();

        $upd = $mysqli->prepare("UPDATE materiales SET cantidad = GREATEST(cantidad - ?, 0) WHERE id_materiales = ?");
        $upd->bind_param('ii', $cantidad, $mat['id_materiales']);
        $upd->execute();
        $upd->close();

        $facturaArr = ['itbm' => $itbm_porcentaje, 'total' => $total, 'fecha' => date('Y-m-d H:i:s')];
        $materialArr = ['nombre' => $mat['nombre'], 'costo' => $precioUnit, 'unidad' => $mat['unidad']];
        $path = FacturaPDF::generar($facturaArr, $materialArr, $cliente['nombre'], $cantidad, $idFactura);

        // Si es descarga directa, enviar el PDF al navegador y salir
        if ($isDownload && file_exists($path)) {
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="factura_' . $idFactura . '.pdf"');
            header('Content-Length: ' . filesize($path));
            readfile($path);
            exit;
        }

        // Si no es descarga directa, mostrar mensajes informativos (modo admin)
        echo "<h2>Factura generada correctamente ✅</h2>";
        echo "<p><a href='../facturas/factura_{$idFactura}.pdf' target='_blank'>📄 Ver factura_{$idFactura}.pdf</a></p>";
        echo "<p><a href='generar.php?cot={$idCot}&download=1'>⬇️ Descargar directamente</a></p>";
        echo "<p><a href='../cotizaciones.php'>Volver a Cotizaciones</a></p>";
    }
}

if (!$isDownload) {
    echo '</div></div>';
    include '../footer.php';
}
?>