<footer id="pie">
  <div class="wrap">
    <p>&copy; <?= date('Y') ?> SUCESOS y MÁS. Todos los derechos reservados.</p>
  </div>
</footer>
<script src="js/script.js"></script>
</body>
</html>
