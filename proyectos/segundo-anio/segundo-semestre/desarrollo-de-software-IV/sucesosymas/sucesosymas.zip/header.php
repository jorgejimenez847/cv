<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>SUCESOS y MÁS</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="css/estilos.css">
<style>
  html, body, * {
    -webkit-user-select: none; 
    -moz-user-select: none;    
    -ms-user-select: none;     
    user-select: none;        
  }
</style>

<script>
  // Bloquear clic derecho
  document.addEventListener('contextmenu', event => event.preventDefault());

  // Bloquear selección de texto y arrastre
  document.addEventListener('selectstart', e => e.preventDefault());
  document.addEventListener('dragstart', e => e.preventDefault());

  // Bloquear combinaciones comunes: Ctrl+C, Ctrl+U, Ctrl+S, Ctrl+A, Ctrl+Shift+I, F12, etc.
  document.addEventListener('keydown', function(e) {
    if (
      // Ctrl + teclas comunes
      (e.ctrlKey && ['c', 'u', 's', 'a', 'x', 'p'].includes(e.key.toLowerCase())) ||
      // Ctrl + Shift + I / J
      (e.ctrlKey && e.shiftKey && ['i', 'j'].includes(e.key.toLowerCase())) ||
      // F12 (DevTools)
      e.key === 'F12'
    ) {
      e.preventDefault();
      e.stopPropagation();
    }
  });

  // Bloquear inspección mediante clic medio (abrir en nueva pestaña)
  document.addEventListener('mousedown', e => {
    if (e.button === 1) e.preventDefault();
  });
</script>

</head>
<body>
<header id="cabecera">
  <div class="wrap">
    <h1>SUCESOS y MÁS</h1>
    <p class="direccion">Dirección: Calle de un lugar 123, Chiriqui</p>
    <div class="userbox">
      <?php if(!empty($_SESSION['cliente'])): ?>
        Hola, <?= htmlspecialchars($_SESSION['cliente']['nombre']) ?> |
        <a href="auth/logout_confirm.php">Salir</a>
      <?php else: ?>
        <a href="auth/login.php">Login</a> | <a href="auth/register.php">Registrarse</a>
      <?php endif; ?>
    </div>
  </div>
</header>
