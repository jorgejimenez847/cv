<?php
// Ajusta según tu entorno
define('DB_HOST','localhost');
define('DB_NAME','sucesosymas');
define('DB_USER','root');
define('DB_PASS',''); // XAMPP default = '' ; en Ubuntu ajusta si tienes password
define('BASE_URL','/sucesosymas/');
