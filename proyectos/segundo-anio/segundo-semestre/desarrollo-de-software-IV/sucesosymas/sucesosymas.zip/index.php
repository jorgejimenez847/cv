<?php
session_start();
$page = $_GET['p'] ?? 'inicio';
include 'header.php';
?>
<div id="contenedor">
    <?php include 'menu.php'; ?>
    <div id="contenido">
        <?php
        switch($page){
            case 'clientes': include 'clientes.php'; break;
            case 'materiales': include 'materiales.php'; break;
            case 'servicios': include 'servicios.php'; break;
            case 'contactos': include 'contactos.php'; break;
            case 'cotizaciones': include 'cotizaciones.php'; break;
            default:
                 echo "<section class='inicio'>
                     <h2>Bienvenido a SUCESOS y MÁS</h2>
                     <p>Somos una plataforma dedicada a la gestión de materiales, cotizaciones y atención personalizada. Aquí puedes ver tus cotizaciones, enviar consultas y obtener facturas de manera rápida y segura.</p>
                     <p>Usa el menú de la izquierda para navegar por las secciones disponibles.</p>
                     <div class='inicio-banner'>
                     <img src='img/banner.jpg' alt='Banner del sitio'>
                     </div>



                 </section>";
                 }
                 ?>
             </div>
         <div style="clear:both"></div>
    </div>
<?php include 'footer.php'; ?>