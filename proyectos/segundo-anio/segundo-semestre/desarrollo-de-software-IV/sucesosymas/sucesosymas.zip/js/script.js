document.addEventListener('DOMContentLoaded', function(){
    const form = document.getElementById('form-contacto');
    if(form){
        form.addEventListener('submit', function(){
            const btn = form.querySelector('button[type="submit"]');
            if(btn) btn.disabled = true;
        });
    }
});
