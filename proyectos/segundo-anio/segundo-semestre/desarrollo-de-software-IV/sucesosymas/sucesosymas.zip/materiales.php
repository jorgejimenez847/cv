<?php

if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'])) {
    header('Location: index.php?p=materiales');
    exit;
}

if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['cliente']) || $_SESSION['cliente']['rol'] !== 'admin') {
    echo "<p style='color:red;'>Acceso restringido a administradores.</p>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $cantidad = intval($_POST['cantidad']);
    $costo = floatval($_POST['costo']);

    if ($cantidad < 0) {
        $msg = "<div class='msg error'>❌ La cantidad no puede ser negativa.</div>";
    } else {
        $stmt = $mysqli->prepare("INSERT INTO materiales (nombre, cantidad, costo, unidad) VALUES (?,?,?,?)");
        $stmt->bind_param('sids', $nombre, $cantidad, $costo, $unidad);
        $stmt->execute();
        $msg = "<div class='msg ok'>✅ Material agregado correctamente.</div>";
    }
}

$res = $mysqli->query("SELECT * FROM materiales ORDER BY id_materiales DESC");


?>
        <h2>Materiales</h2>
        <?= $msg ?? '' ?>
        <form method="post">
            <label>Nombre:<input name="nombre" required></label><br>
            <label>Cantidad:<input name="cantidad" type="number" min="0" required></label><br>
            <label>Costo:<input name="costo" type="number" step="0.01" required></label><br>
            <button>Guardar</button>
        </form>

        <table class="tabla">
            <thead><tr><th>ID</th><th>Nombre</th><th>Cantidad</th><th>Costo</th></tr></thead>
            <tbody>
                <?php while($m = $res->fetch_assoc()): ?>
                <tr>
                    <td><?= $m['id_materiales'] ?></td>
                    <td><?= htmlspecialchars($m['nombre']) ?></td>
                    <td><?= $m['cantidad'] ?></td>
                    <td><?= number_format($m['costo'], 2) ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>