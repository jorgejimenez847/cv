<?php
$current = $_GET['p'] ?? 'inicio';
$rol = $_SESSION['cliente']['rol'] ?? 'cliente';
?>
<aside id="menu">
  <nav>
    <ul>
      <li><a href="index.php" class="<?= $current=='inicio' ? 'activo' : '' ?>">Inicio</a></li>
      <?php if($rol == 'admin'): ?>
        <li><a href="index.php?p=clientes" class="<?= $current=='clientes' ? 'activo' : '' ?>">Clientes</a></li>
        <li><a href="index.php?p=materiales" class="<?= $current=='materiales' ? 'activo' : '' ?>">Materiales</a></li>
      <?php endif; ?>
      <li><a href="index.php?p=cotizaciones" class="<?= $current=='cotizaciones' ? 'activo' : '' ?>">Cotizaciones</a></li>
      <li><a href="index.php?p=contactos" class="<?= $current=='contactos' ? 'activo' : '' ?>">Contactos</a></li>
    </ul>
  </nav>
</aside>
